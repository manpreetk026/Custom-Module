<?php
namespace Kinex\CustomModule\Plugin\Swatches\Block\Product\Renderer;
 
class Configurable
{
    protected $_productFactory;
    protected $logger;
    public function __construct(
        \Magento\Catalog\Model\ProductFactory $_productFactory,
        \Psr\Log\LoggerInterface $logger,
    ) {
        $this->_productFactory = $_productFactory;
        $this->logger = $logger;
    }
 
    public function afterGetJsonConfig(
        \Magento\Swatches\Block\Product\Renderer\Configurable $subject, $result
	) {
 
    $jsonResult = json_decode($result, true);
    $jsonResult['ids'] = [];
    $jsonResult['names'] = [];
    $jsonResult['not_for_sale'] = [];
    $jsonResult['description'] = [];
        foreach ($subject->getAllowProducts() as $simpleProduct) {
            $product = $this->_productFactory->create()->setStoreId(0)->load($simpleProduct->getId());
            $jsonResult['ids'][$simpleProduct->getId()] =  $simpleProduct->getId();
            $jsonResult['names'][$simpleProduct->getId()] = $simpleProduct->getName();
            $jsonResult['not_for_sale'][$simpleProduct->getId()] = $product->getAttributeText('not_for_sale');
            $jsonResult['description'][$simpleProduct->getId()] = $product->getData('description');
	}
    $result = json_encode($jsonResult);
        return $result;
	}
}