define([
    'jquery',
    'mage/utils/wrapper'
], function ($, wrapper) {
	'use strict';
 
    return function(targetModule){
        var updatePrice = targetModule.prototype._UpdatePrice;
        targetModule.prototype.configurableSku = $('div.product-info-main .sku .value').html();
        targetModule.prototype.configurableName = $('div.product-info-main .page-title .base').html();
  
        var updatePriceWrapper = wrapper.wrap(updatePrice, function(original){
            var allSelected = true;
            for(var i = 0; i<this.options.jsonConfig.attributes.length;i++){
                if (!$('div.product-info-main .product-options-wrapper .swatch-attribute.' + this.options.jsonConfig.attributes[i].code).attr('option-selected')){
                	allSelected = false;
                }
            }
            var productName = this.options.jsonConfig.names[this.getProduct()];
            var notForSale = this.options.jsonConfig.not_for_sale[this.getProduct()];
            var description = this.options.jsonConfig.description[this.getProduct()];
         console.log(description);
            // if(productName) {
            //    $('[data-price-type="finalPrice"]').html(productName);
            // }
            var simpleSku = this.configurableSku;
            var simpleName = this.configurableName
            if (allSelected){
                var products = this._CalcProducts();
                simpleSku = this.options.jsonConfig.skus[products.slice().shift()];
                simpleName = this.options.jsonConfig.names[products.slice().shift()];
            }
            if(notForSale == 'Yes') {
               
                $('[data-price-type="finalPrice"]').hide();
                $('div.page-main-description .product .value').text("dcgfhfgh");
                $('#product-addtocart-button').hide();
                
            }
            else
            {
                $('[data-price-type="finalPrice"]').show();
                $('#product-addtocart-button').show();
            }

              return original();
        });
 
        targetModule.prototype._UpdatePrice = updatePriceWrapper;
        return targetModule;
	};
});